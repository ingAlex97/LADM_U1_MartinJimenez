package com.example.ladm_u1_practica2_martnjimenez

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


//--------------- GUARDAR -------------------------
        btnGuardar.setOnClickListener {
            if (editTextNombre.text.isEmpty()) {
                mensaje("Precaución", "No has escrito el nombre de tu archivo")
            } else {
                if (rbGuardarI.isChecked) {
                    //mensaje ("Seleccionaste guardar en memoria interna")
                    guardarInterna()
                }

                if (rbGuardarE.isChecked) {
                    guardarExterna()
                }

                if (!rbGuardarI.isChecked && !rbGuardarE.isChecked) {
                    mensaje("!ATENCIÓN¡", "Seleccione el lugar de almacenamiento")
                }
            }
        } //boton guardar
//-------------------------------------------


//------------------- ABRIR ----------------
        btnAbrir.setOnClickListener {
            if (rbGuardarI.isChecked) {
                abrirInterna()

            }

            if (rbGuardarE.isChecked) {
                abrirExterna()
            }
            if (!rbGuardarI.isChecked && !rbGuardarE.isChecked) {
                mensaje("ATENCIÓN", "Seleccione el lugar de donde desea extraer el archivo")
            }
        }//boton abrir
//-------------------------------------------

    }//onCreate

//----------------------------------------- FUNCIONES  ---------------------------------------------

//---------------- Funcion guardar en memoria INTERNA ------------

    fun guardarInterna() {
        try {
            var flujoSalida = OutputStreamWriter(
                openFileOutput(
                    "" + editTextNombre.text.toString() + ".txt",
                    Context.MODE_PRIVATE
                )
            )

            var data = editText.text.toString()

            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()

            mensaje(
                "¡Exito!",
                "Se creó el archivo '" + editTextNombre.text.toString() + ".txt' en memoria interna"
            )
            textView5.setText("En interna:  "+editTextNombre.text.toString()+".txt")
            asignarTextos("", "")

        } catch (error: IOException) {
            mensaje("ERROR", error.message.toString())
        }
    } // fin guardarInterna
//---------------------------------------------


    //---------------- Funcion guardar en memoria EXTERNA ------------
    fun guardarExterna() {
        if (noSD()) {
            mensaje("Aviso", "No hay memoria externa")
            return
        }
        solicitarPermisos()

        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivo = File(rutaSD.absolutePath, "" + editTextNombre.text.toString()+".txt")
            var flujoSalida = OutputStreamWriter(FileOutputStream(datosArchivo))

            var data = editText.text.toString()

            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()

            mensaje(
                "¡Exito!",
                " se creó el archivo " + editTextNombre.text.toString() + ".txt' en memoria externa"
            )

            textView6.setText("En SD: "+ editTextNombre.text.toString()+".txt")
            asignarTextos("", "")
        } catch (error: IOException) {
            mensaje("ERROR", error.message.toString())
        }

    }
//---------------------------------------------


    //---------------- Funcion abrir desde memoria INTERNA -----------
    fun abrirInterna() {

        try {
            var flujoEntrada =
                BufferedReader(InputStreamReader(openFileInput("" + editTextNombre.text.toString() + ".txt")))

            var data = flujoEntrada.readLine()

            asignarTextos(data, editTextNombre.text.toString())


        } catch (error: IOException) {
            mensaje("ERROR", error.message.toString())
        }

    }// fin abrir interna
//---------------------------------------------





//---------------- Funcion abrir desde memoria INTERNA ------------
fun abrirExterna(){
    if(noSD()){
        mensaje("Aviso","No hay memoria externa en el dispositivo")
        return
    }

    solicitarPermisos()

    try{
        var rutaSD = Environment.getExternalStorageDirectory()
        var datosArchivo = File(rutaSD.absolutePath,""+editTextNombre.text.toString()+".txt")

        var flujoEntrada = BufferedReader(InputStreamReader(FileInputStream(datosArchivo)))


        var data = flujoEntrada.readLine()

        asignarTextos(data,editTextNombre.text.toString())


    }catch (error: IOException){
        mensaje("ERROR",error.message.toString())}
}//funcion abrir archivos de memoria externa

//---------------------------------------------


    fun mensaje( t:String,m:String ){

        AlertDialog.Builder(this)
            .setTitle(t)
            .setMessage(m)
            .setPositiveButton("ok"){d,i->}
            .show()
    }

    fun asignarTextos(t1:String,t2:String){
        editText.setText(t1)
        editTextNombre.setText(t2)
    }

    fun noSD():Boolean{
        var estado = Environment.getExternalStorageState()

        if(estado!= Environment.MEDIA_MOUNTED) return true

        return false
    }

    fun solicitarPermisos() {
        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED)
        {
            //Permiso no concedido entonces se solicita

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), 0
            )
        }
        return
    }
}
