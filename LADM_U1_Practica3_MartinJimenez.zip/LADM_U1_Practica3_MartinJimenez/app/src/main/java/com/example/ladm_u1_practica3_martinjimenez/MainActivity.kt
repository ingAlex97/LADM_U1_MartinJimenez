package com.example.ladm_u1_practica3_martinjimenez

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {
    val vector: Array<String> = Array(10,{""})


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        solicitarPermisos()

        btnAsignar.setOnClickListener{
            asignar()
        }

        btnMostrar.setOnClickListener {
            mostrar()
        }

        btnGuardar.setOnClickListener {
            guardarSD()
        }

        btnLeer.setOnClickListener {
            leerSD()
        }
    }


    private fun asignar() {
        if (valor.text.isEmpty() || posicion.text.isEmpty() ) {
            mensaje("Atención","Todos los campos deben ser llenados")
            return
        }

            vector.set(posicion.text.toString().toInt(),valor.text.toString())




    }//funcion asignar



    private fun mostrar() {
        //El codigo del ADAPTER para mostrar ITEMS en el ListView

        var adaptadorListView =  ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, vector)
        listaView.adapter = adaptadorListView

    }//Funcion mostrar

    private fun guardarSD() {
        if (noSD()) {
            mensaje("Aviso", "No hay memoria externa")
            return
        }

    var datos =""

        (0..9).forEach {
            datos += vector[it]+"&"
            vector[it]=""
        }
        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivo = File(rutaSD.absolutePath, "" + txtNombreG.text.toString()+".txt")
            var flujoSalida = OutputStreamWriter(FileOutputStream(datosArchivo))


            flujoSalida.write(datos)
            flujoSalida.flush()
            flujoSalida.close()

            mensaje(
                "¡Exito!",
                " se creó el archivo '" + txtNombreG.text.toString() + ".txt' en memoria externa"

            )

            var adaptadorListView =  ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, vector)
            listaView.adapter = adaptadorListView
        } catch (error: IOException) {
            mensaje("ERROR", error.message.toString())
        }

    }// funcion guardarSD


    private fun leerSD() {
        if(noSD()){
            mensaje("Aviso","No hay memoria externa en el dispositivo")
            return
        }



        try{
            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivo = File(rutaSD.absolutePath,""+txtNombreL.text.toString()+".txt")

            var flujoEntrada = BufferedReader(InputStreamReader(FileInputStream(datosArchivo)))


            var data = flujoEntrada.readLine().split("&")

            (0..9).forEach{
                vector[it]=data[it]
            }
            mostrar()

        }catch (error: IOException){
            mensaje("ERROR",error.message.toString())}
    }// funcion leerSD


    private fun mensaje(t:String, m:String){
        AlertDialog.Builder(this)
            .setTitle(t)
            .setMessage(m)
            .setPositiveButton("ok"){d,i->}
            .show()

    }

    fun solicitarPermisos() {
        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED)
        {
            //Permiso no concedido entonces se solicita

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), 0
            )
        }
        return
    }

    fun noSD():Boolean{
        var estado = Environment.getExternalStorageState()

        if(estado!= Environment.MEDIA_MOUNTED) return true

        return false
    }

}
