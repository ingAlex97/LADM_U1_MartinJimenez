package com.example.ladm_u1_practica1_martinjimenez

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Main4Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
    }
}
